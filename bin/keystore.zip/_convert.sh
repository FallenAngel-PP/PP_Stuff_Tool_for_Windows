#!/bin/bash

openssl pkcs8 -in platform.pk8 -inform DER -outform PEM -out platform.priv.pem -nocrypt
openssl pkcs12 -export -in platform.x509.pem -inkey platform.priv.pem -out platform.pk12 -name android
keytool -importkeystore -destkeystore platform.jks -srckeystore platform.pk12 -srcstoretype PKCS12 -alias android

openssl pkcs8 -in testkey.pk8 -inform DER -outform PEM -out testkey.priv.pem -nocrypt
openssl pkcs12 -export -in testkey.x509.pem -inkey testkey.priv.pem -out testkey.pk12 -name android
keytool -importkeystore -destkeystore testkey.jks -srckeystore testkey.pk12 -srcstoretype PKCS12 -alias android

openssl pkcs8 -in shared.pk8 -inform DER -outform PEM -out shared.priv.pem -nocrypt
openssl pkcs12 -export -in shared.x509.pem -inkey shared.priv.pem -out shared.pk12 -name android
keytool -importkeystore -destkeystore shared.jks -srckeystore shared.pk12 -srcstoretype PKCS12 -alias android

openssl pkcs8 -in media.pk8 -inform DER -outform PEM -out media.priv.pem -nocrypt
openssl pkcs12 -export -in media.x509.pem -inkey media.priv.pem -out media.pk12 -name android
keytool -importkeystore -destkeystore media.jks -srckeystore media.pk12 -srcstoretype PKCS12 -alias android
